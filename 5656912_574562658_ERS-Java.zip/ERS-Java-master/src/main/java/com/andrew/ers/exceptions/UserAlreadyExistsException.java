package com.andrew.ers.exceptions;

public class UserAlreadyExistsException extends RuntimeException {

	private static final long serialVersionUID = 104950890016322169L;

}
