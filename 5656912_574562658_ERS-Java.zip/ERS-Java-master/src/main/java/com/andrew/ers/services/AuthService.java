package com.andrew.ers.services;

import org.springframework.stereotype.Service;

@Service
public class AuthService {
	
}
